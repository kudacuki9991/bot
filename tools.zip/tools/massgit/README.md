# Mass-GIT


Mass .git scanner with Python


## Update


+ Add multi threading
+ Found git will saved to .txt
+ Fix false positive

Usage : python git.py [yourlist.txt] [thread]

Ex : python git.py domen.txt 10





![image](https://user-images.githubusercontent.com/39010800/179026365-c052c6de-9a32-413f-ab4d-309d07199782.png)

