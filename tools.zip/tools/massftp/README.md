# FTPwn
.vscode/sftp.json Arbitary File Upload Exploit

## POC
<img src="https://raw.githubusercontent.com/1337r0j4n/FTPwn/main/a.jpeg">
