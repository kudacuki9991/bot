# CVE-2023-25136
OpenSSH 9.1 vulnerability mass scan and exploit

# Détails sur la vulnérabilité

Pour rappel, OpenSSH est un logiciel qui implémente le protocole SSH, très fréquemment utilisé pour se connecter à des machines sous Linux (ou Windows) de façon sécurisée pour effectuer de l'administration à distance.

Introduit dans OpenSSH 9.1, la faille de sécurité CVE-2023-25136 affecte le processus de pré-authentification de SSH. En l'exploitant, un attaquant pourrait corrompre la mémoire et parvenir à exécuter du code arbitraire sur la machine, sans être authentifié sur le serveur cible.

# utilisation

Exécuter le script au choix ``scan de liste d'adresses IP`` où ``exploitation direct d'une IP vulnérable``

# requirements

• paramiko : pour l'installer il suffit de taper
``pip install paramiko``

• pyfiglet : pour l'installer il suffit de taper
``pip install pyfiglet``

• termcolor : pour l'installer il suffit de taper
``pip install termcolor``

# More 

<a href="https://jfrog.com/blog/openssh-pre-auth-double-free-cve-2023-25136-writeup-and-proof-of-concept/">Plus de détails sur la vulnérabilité </a>
# Website

https://christbowel.ml

CTF player 💥 | Bug hunter 💻 | apprenti pentester 🎭
