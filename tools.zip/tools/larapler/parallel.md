# Install Parallel
Linux : <br>
<b>- ubuntu/debian</b> <br># <i>sudo apt-get install parallel -y</i><br><b>- centos</b> <br># <i>sudo yum install parallel -y</i><br><br>
Windows : <br>
You can install WSL (windows subsystem linux) then do install like linux<br><br><b>* If you want use windows without installing WSL, install <a href="https://git-scm.com/download/win">GitBash</a></b>
<br># <i>curl pi.dk/3/ > install.sh <br># sha1sum install.sh | grep 12345678 <br># md5sum install.sh <br># sha512sum install.sh <br># bash install.sh</i><br>
