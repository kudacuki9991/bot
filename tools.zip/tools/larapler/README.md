# LARAPLER - Laravel Random Exploit 
- Requirements : Python2, Python3, PHP-cli, PHP-curl, Bash, Parallel<br>
- How to Install Parallel check <a href="https://github.com/im-hanzou/larapler/blob/main/parallel.md">Here</a><br>
- If you got error : python error no module named xxx ( just run ```pip install modulename``` )
<h3>Another Exploit</h3>
- Laravel Debug RCE : <a href="https://github.com/wibuheker/Laravel-RCE"> Here </a><br>
- Laravel Exploit<a href="https://github.com/im-hanzou/Laravel_Exploit"> Here </a><br>
- LaCrot <a href="https://github.com/im-hanzou/LaCrot"> Here </a><br>
- Laravel Checker (exe) <a href="https://github.com/im-hanzou/Laravel-Checker"> Here </a><br>
- Laravel Scanner (exe) <a href="https://github.com/im-hanzou/Laravel-Scanner"> Here </a>/<a href="https://github.com/im-hanzou/Laravel-Scanner-1"> Mirror </a><br>
- Laravel Scanner (bash) <a href="https://github.com/im-hanzou/LaravelScanner"> Here </a><br>
- CannabisLaravelEnv <a href="https://github.com/im-hanzou/CannabisLaravelenv"> Here </a><br>
<h2>Thanks for the all Tools Creator | Copyright by the all Tools Creator</h2>
